

<?php $__env->startSection('title' , 'Nuevo producto'); ?>

<?php $__env->startSection('content_tituloprincipal'); ?>
    <h1 class="m-0">Registrar nuevo producto</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <form action="<?php echo e(route('agregarproducto')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body row">
                        <div class="form-group col-md-6">
                            <label for="">Nombre de producto</label>
                            <input type="text" class="form-control form-control-sm" name="nombre_producto">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Código de producto</label>
                            <input type="text" class="form-control form-control-sm" name="codigo_producto">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Tipo de producto</label>
                            <select name="tipo_producto" id="" class="form-control form-control-sm">
                                <option value="">[SELECCIONE]</option>
                                <?php $__currentLoopData = $tipo_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tipo_producto->ID_TProd); ?>"><?php echo e($tipo_producto->Nombre_TProd); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Proveedor</label>
                            <select name="proveedor" id="" class="form-control form-control-sm">
                                <option value="">[SELECCIONE]</option>
                                <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($proveedor->ID_TProv); ?>"><?php echo e($proveedor->Nombre_Prov); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Precio de venta</label>
                            <input type="text" class="form-control form-control-sm" name="precio_venta">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Precio de compra</label>
                            <input type="text" class="form-control form-control-sm" name="precio_compra">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Stock actual</label>
                            <input type="text" class="form-control form-control-sm" name="stock_actual">
                        </div>

                        <div class="form-group col-md-6">
                            <label for="">Stock mínimo</label>
                            <input type="text" class="form-control form-control-sm" name="stock_minimo">
                        </div>
                    </div>
                </div>
            <!-- /.card -->
            
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>


      <div class="row">
        <div class="form-group col-md-2">
            <button class="btn btn-sm btn-success btn-block"><i class="fas fa-save"></i> Registrar</button>
        </div> 

        <div class="form-group col-md-2">
            <a href="<?php echo e(route('productos')); ?>" class="btn btn-sm btn-danger btn-block"><i class="fas fa-times-circle"></i> Cancelar</a>
        </div>
      </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('input[name="fecha_orden"]').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
        $('input[name="fecha_entrega"]').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectofinal_laravel\resources\views/nuevoproducto.blade.php ENDPATH**/ ?>