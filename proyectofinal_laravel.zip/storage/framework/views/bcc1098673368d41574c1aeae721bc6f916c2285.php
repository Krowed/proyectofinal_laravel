

<?php $__env->startSection('title' , 'Home'); ?>

<?php $__env->startSection('content_tituloprincipal'); ?>
    <h1 class="m-0">Sistema de inventario Global Tec</h1>
    <span class="text-muted">¡Bienvenido, <?php echo e(session('usuario')['email']); ?>!</span>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info">
            <div class="inner">
            <h3>
                <?php echo e($ingresos <= 0 ? 0 : $ingresos); ?>

            </h3>
            <p>Entradas</p>
            </div>
            <div class="icon">
            <i class="ion ion-bag"></i>
            </div>
            <a href="<?php echo e(route('ingresos')); ?>" class="small-box-footer">Ver detalle <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success">
            <div class="inner">
            <h3><?php echo e($productos <= 0 ? 0 : $productos); ?></h3>
            <p>
                Productos
            </p>
            </div>
            <div class="icon">
            <i class="ion ion-stats-bars"></i>
            </div>
            <a href="<?php echo e(route('productos')); ?>" class="small-box-footer">Ver detalle <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning">
            <div class="inner">
            <h3>
                <?php echo e($salidas <= 0 ? 0 : $salidas); ?>

            </h3>
            <p>
                Salidas
            </p>
            </div>
            <div class="icon">
            <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(route('salidas')); ?>" class="small-box-footer">Ver detalle <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger">
            <div class="inner">
            <h3>
                <?php echo e($ordenes <= 0 ? 0 : $ordenes); ?>

            </h3>
            <p>Órdenes</p>
            </div>
            <div class="icon">
            <i class="ion ion-pie-graph"></i>
            </div>
            <a href="<?php echo e(route('ordenes')); ?>" class="small-box-footer">Ver detalle <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        </div>
        <!-- ./col -->
    </div>
    <!-- /.row -->


    <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title" style="font-weight: bold">LISTADO DE PRODUCTOS DE BAJO STOCK</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body"> 
              <table id="example2" class="table table-bordered table-hover table-sm">
                <thead class="text-center">
                <tr>
                  <th>ID</th>
                  <th>Producto</th>
                  <th>Categoría</th>
                  <th>Precio</th>
                  <th>Stock</th>
                </tr>
                </thead>

                <tbody class="text-center">
                <?php $__currentLoopData = $productos_bajostock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto->ID_Prod); ?></td>
                        <td><?php echo e($producto->Nombre_Prod); ?></td>
                        <td><?php echo e($producto->tipo_producto); ?></td>
                        <td><?php echo e($producto->PrecioVent_Prod); ?></td>
                        <td><?php echo e($producto->StockActual_Prod); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectofinal_laravel\resources\views/home.blade.php ENDPATH**/ ?>